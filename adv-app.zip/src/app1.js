//const element = <h1>Hello,World</h1>;


//const name='React is Easy';
//const element1=<h1>Hi, {name}</h1>;

console.log('Hello World');