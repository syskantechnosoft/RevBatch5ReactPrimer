import logo from './logo.svg';
import './App.css';
import HelloWorldF from './HelloWorldf';
import HelloWorld from './HelloWorld';
import HelloMessage from './helloMessage';
//function based component
function App() {
  return (
    <div className="App">
      <header className="App-header">
        <img src={logo} className="App-logo" alt="logo" />
        <p>
          Edit <code>src/App.js</code> and save to reload. Updated Code
        </p>
        <HelloWorld/>
        <HelloWorldF/>
        <h4>Single Props</h4>
        <HelloMessage name="Revature" />
        <h4>Double Props</h4>
        <HelloMessage name="Siva" message="Welcome to Props" />
        <a
          className="App-link"
          href="https://reactjs.org"
          target="_blank"
          rel="noopener noreferrer"
        >
          Learn React
        </a>

      </header>
    </div>
  );
}

export default App;
