
function HelloWorldF() {
    return (
        <div>
            <div className="App">
                <header className="App-header">
                    <h3> HelloWorld Functional Component</h3>
                </header>
            </div>
            <div className="App">
                <header className="App-header">
                    <h3> Second Div</h3>
                </header>
            </div>
        </div>
    );

}

export default HelloWorldF;