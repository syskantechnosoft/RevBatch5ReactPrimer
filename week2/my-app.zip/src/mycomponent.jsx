// import logo from './logo.svg';
import './App.css';
//functional component 
function MyComponent() {
  return (
    <div className="App">
        <h3>Welcome to Component</h3>
    </div>
  );
}

export default MyComponent;