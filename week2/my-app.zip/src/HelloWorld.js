import React from 'react';

class HelloWorld extends React.Component {
    render() {
        return (
            <div className="App">
                <header className="App-header">
                    <h3> HelloWorld Component</h3>
                </header>
            </div>);
    }
}
export default HelloWorld;