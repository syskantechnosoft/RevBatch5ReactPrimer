import React from 'react';

class HelloMessage extends React.Component {
    render() {
        const message = this.props.message ? this.props.message : `Hi, Hello!!!`;
        return (
            <div>
                Message from {this.props.name} : {message}
            </div>
        );
    }
       
}

export default HelloMessage;